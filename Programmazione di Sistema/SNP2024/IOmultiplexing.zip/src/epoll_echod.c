#define _XOPEN_SOURCE
#include <limits.h>      /* system limits constants, types and functions */
#include <sys/types.h>   /* primitive system data types */
#include <unistd.h>      /* unix standard library */
#include <arpa/inet.h>   /* IP addresses conversion utilities */
#include <sys/socket.h>  /* socket constants, types and functions */
#include <stdio.h>	 /* standard I/O library */
#include <time.h>        /* date and time constants, types and functions */
#include <syslog.h>      /* syslog system functions */
#include <signal.h>      /* signal constants, types and functions */
#include <errno.h>       /* error definitions and routines */
#include <string.h>      /* C strings library */
#include <stdlib.h>      /* C standard library */
#include <sys/epoll.h>    /* epoll syscall */

#include "macros.h"
#include "Gapil.h"

#define BACKLOG 10
#define MAXLINE 256
int debugging = 0;  /* debug info printing option: default is no debug */
/* Subroutines declaration */
void usage(void);
void PrintErr(char * error);
/* Program beginning */
int main(int argc, char *argv[])
{
/* 
 * Variables definition  
 */
    int waiting = 0;
    int compat = 0;
    struct sockaddr_in s_addr, c_addr;
    socklen_t len;
    char buffer[MAXLINE];
    struct epoll_event chlist, *evlist;
    int list_fd, fd;
    int nread, nwrite;
    int i, nev, n = 256;
    /*
     * Input section: decode parameters passed in the calling 
     * Use getopt function
     */
    opterr = 0;	 /* don't want writing to stderr */
    while ( (i = getopt(argc, argv, "hdicw:n:")) != -1) {
	switch (i) {
	/* 
	 * Handling options 
	 */ 
	case 'h':  
	    printf("Wrong -h option use\n");
	    usage();
	    return(0);
	    break;
	case 'c':
	    compat = 1;
	    break;
	case 'd':
	    debugging = 1;
	    break;
	case 'w':
	    waiting = strtol(optarg, NULL, 10);
	    break;
	case 'n':
	    n = strtol(optarg, NULL, 10);
	    break;
	case '?':   /* unrecognized options */
	    printf("Unrecognized options -%c\n",optopt);
	    usage();
	default:    /* should not reached */
	    usage();
	}
    }
    /* ***********************************************************
     * 
     *		 Options processing completed
     *
     *		      Main code beginning
     * 
     * ***********************************************************/
    /* Main code begin here */
    if (compat) {                             /* install signal handler */
	Signal(SIGCHLD, HandSigCHLD);         /* non restarting handler */
    } else {
	SignalRestart(SIGCHLD, HandSigCHLD);  /* restarting handler */
    }
    /* create socket */
    if ( (list_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
	perror("Socket creation error");
	exit(1);
    }
    /* initialize address */
    memset((void *)&s_addr, 0, sizeof(s_addr));   /* clear server address */
    s_addr.sin_family = AF_INET;                  /* address type is INET */
    s_addr.sin_port = htons(7000);                   /* echo port is 7000 */
    s_addr.sin_addr.s_addr = htonl(INADDR_ANY);   /* connect from anywhere */
    /* bind socket */
    if (bind(list_fd, (struct sockaddr *)&s_addr, sizeof(s_addr)) < 0) {
	perror("bind error");
	exit(1);
    }
    /* main body */
    if (listen(list_fd, BACKLOG) < 0 ) {
	PrintErr("listen error");
	exit(1);
    }
    if (waiting) sleep(waiting);

    /* create a new kernel event queue */
    int epfd = epoll_create(n);
    struct epoll_event event;
    event.data.fd = list_fd;
    event.events = EPOLLIN;
    epoll_ctl(epfd, EPOLL_CTL_ADD, list_fd, &event);

    /* main loop, wait for connection and data inside a select */
    evlist = (struct epoll_event*)calloc(n, sizeof(struct epoll_event));
    while (1) {
	memset(evlist, 0, n * sizeof(struct epoll_event));
	while ( ((nev = epoll_wait(epfd, evlist, n, -1)) < 0)
		&& (errno == EINTR));         /* wait for data or connection */
	if (nev < 0) {                          /* on real error exit */
	    PrintErr("poll error");
	    exit(1);
	}
	/* loop on open connections */
	for (i = 0; i < nev; i++) {
		if (evlist[i].data.fd == list_fd) {
			len = sizeof(c_addr);             /* and call accept */
			if ((fd = accept(list_fd, (struct sockaddr *)&c_addr, &len)) < 0) {
				PrintErr("accept error");
				exit(1);
			}
			struct epoll_event event;
			event.data.fd = fd;
			event.events = EPOLLIN;
			epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &event);
			continue;
		}
		if (evlist[i].events & EPOLLIN) {
			nread = read(evlist[i].data.fd, buffer, MAXLINE);     /* read operations */
			if (nread < 0) {
				PrintErr("Errore in lettura");
				exit(1);
			}
			if (nread == 0) {
				debug("fd %d chiuso\n", evlist[i].data.fd);
				close(evlist[i].data.fd);                /* close file */
				struct epoll_event event;
				epoll_ctl(epfd, EPOLL_CTL_DEL, evlist[i].data.fd, &event);
				continue;                /* continue loop on open */
			}
			nwrite = FullWrite(evlist[i].data.fd, buffer, nread); /* write data */
			if (nwrite) {
				PrintErr("Errore in scrittura");
				exit(1);
			}
		}
	}
    }
    free(evlist);
    /* normal exit, never reached */
    exit(0);
}
/*
 * routine to print usage info and exit
 */
void usage(void) {
    printf("Elementary echo server\n");
    printf("Usage:\n");
    printf("  echod [-h] \n");
    printf("  -h	   print this help\n");
    printf("  -d	   write debug info\n");
    printf("  -c	   disable BSD signal semantics\n");
    printf("  -n N	   set max contemporary connection\n");
    printf("  -w N	   wait N sec. before calling poll\n");
    exit(1);
}
/*
 * routine to print error on stout or syslog
 */
void PrintErr(char * error) {
	perror(error);
}
