#include "apue.h"

static void
sig_catch(int signo)
{
	printf("signal caught\n");
	tty_reset(STDIN_FILENO);
	exit(0);
}

int
main(void)
{
	int		i,x=0,y=0;
	char	c;
	//cautela dai segnali
	if (signal(SIGINT, sig_catch) == SIG_ERR)	/* catch signals */
		err_sys("signal(SIGINT) error");
	if (signal(SIGQUIT, sig_catch) == SIG_ERR)
		err_sys("signal(SIGQUIT) error");
	if (signal(SIGTERM, sig_catch) == SIG_ERR)
		err_sys("signal(SIGTERM) error");

	if (tty_raw(STDIN_FILENO) < 0)
		err_sys("tty_raw error");
	printf("Enter raw mode characters, terminate with DELETE\n");
	while ((i = read(STDIN_FILENO, &c, 1)) == 1) {
		if (c == 0177)		 /* 0177 = ASCII DELETE */
			break; 
		//sposto il cursore
		if (c == 0150)	{	/* 0150 = h = left */
			x=x-1;
			}
		if (c == 0153)	{	/* 0153 = k = right */
			x=x+1;
			}
		if (c == 0155)	{	/* 0155 = m = down */
			y=y+1;
			}
		if (c == 0165)	{	/* 0165 = u = up */
			y=y-1;
			
			printf("\033[2A"); 
			//codici per fare modifiche nel terminale, cambiare i colori,... si chiamano printf escape
			//puoi trovarli su https://web.archive.org/web/20190624214929/http://www.termsys.demon.co.uk/vtansi.htm
			}
		printf("\033[2J");
		printf("\033[%d;%dH", y, x);
		printf("🕷    ");
		fflush(stdout);
	}
	if (tty_reset(STDIN_FILENO) < 0)
		err_sys("tty_reset error");
	if (i <= 0)
		err_sys("read error");
	exit(0);
}
